package com.studentmanagementsystem;

import java.util.ArrayList;
import java.util.List;

public class Student {
	 private String name;
	    private List<String> courses;

	    public Student(String name) {
	        this.name = name;
	        this.courses = new ArrayList<>();
	    }

	    public String getName() {
	        return name;
	    }

	    public List<String> getCourses() {
	        return courses;
	    }

	    public void enroll(String course) {
	        courses.add(course);
	        System.out.println(name + " has enrolled in " + course);
	    }

	    public void drop(String course) {
	        if (courses.contains(course)) {
	            courses.remove(course);
	            System.out.println(name + " has dropped " + course);
	        } else {
	            System.out.println(name + " is not enrolled in " + course);
	        }
	    }

}
