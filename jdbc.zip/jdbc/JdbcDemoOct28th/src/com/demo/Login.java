package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Login {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter username");
	String uname=sc.next();
	System.out.println("Enter password");
     String pwd= sc.next();
     
	Class.forName("com.mysql.jdbc.Driver");
	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/oct28th", "root", "Sathya@123");
    PreparedStatement psmt=conn.prepareStatement("select * from login where username=? and password=?");
    
    psmt.setString(1, uname);
    psmt.setString(2, pwd);
    
   ResultSet res= psmt.executeQuery();
	
   if(res.next())
   {
	   System.out.println("login suucess...welcome to home page");
   }
   else {
	   System.out.println("oopss...login denied");
   }
}
}
