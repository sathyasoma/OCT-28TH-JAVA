package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	//1.loading the driver class
	Class.forName("com.mysql.jdbc.Driver");
	//2.get the connection 
	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/oct28th", "root", "Sathya@123");
	//3.create statement 
	Statement stmt=conn.createStatement();
	//4.execute statment
	//ddl-execute(),dml-executeUpdate drl-executeQuery()
	//boolean result=stmt.execute("create table student(stid int,stname varchar(20),stmarks int)");
	//int result=stmt.executeUpdate("insert into student values(124,'sathya',59)");
	
	//int result=stmt.executeUpdate("update student set stname='soma' where stid=124");
	
	
	ResultSet res=stmt.executeQuery("select * from student");
	
	while(res.next())
	{
		System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getInt(3));
	}
	
	//int result=stmt.executeUpdate("delete from student where stid=123");
	//5.close the connection
	conn.close();
	//System.out.println("record deleted :"+result);
}
}
