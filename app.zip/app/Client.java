package com.emp.app;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Client {

	public static void main(String[] args) throws EmployeeException {

		HashMap<Integer, Employee> employee = new HashMap<Integer, Employee>();
		Scanner sc = new Scanner(System.in);
		int empid = 77493;

		while (true) {
			System.out.println("***Employee Mangaement Application***");
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Get Employee");
			System.out.println("4.Delete Employee");
			System.out.println("5.Get All Employees");

			try {
				int option = sc.nextInt();
				switch (option) {
				case 1:
					System.out.println("Adding Employee Details");
					System.out.println("Enter Employee Name");
					String empName = sc.next();
					System.out.println("Enter Employee salary");
					int empSal = sc.nextInt();
					System.out.println("Enter Employee Address");
					String empAdd = sc.next();
					System.out.println("Enter Employee Mail id");
					String empMail = sc.next();

					if (empName.isEmpty() || empSal <= 0 || empAdd.isEmpty() || empMail.isEmpty()) {
						throw new InvalidEmployeeInput("employee data is invalid");
					}
					if (employee.containsKey(empid)) {
						throw new EmployeeAlredyExistsException("Employee " + empid + " already exists");
					}

					Employee emp = new Employee(empName, empSal, empAdd, empMail);

					employee.put(empid++, emp);
					System.out.println("Employee inserted Succfully :" + empid);
					break;
				case 2:
					System.out.println("Updating Employee Details");
					System.out.println("Enter Employee Id to update");
					int eid = sc.nextInt();
//				if(!employee.containsKey(eid))
//				{
//					throw new EmployeeNotFoundException("Employee "+eid +" not found");
//				}

					System.out.println("Enter Employee Name");
					String empname = sc.next();
					System.out.println("Enter Employee salary");
					int empsal = sc.nextInt();
					System.out.println("Enter Employee Address");
					String empadd = sc.next();
					System.out.println("Enter Employee Mail id");
					String empmail = sc.next();

					Employee empupdate = new Employee(empname, empsal, empadd, empmail);

					employee.put(eid, empupdate);

					System.out.println("Employee updated :" + eid);
					break;
				case 3:
					System.out.println("Enter Employee id to get details");
					int eid1 = sc.nextInt();
					if (!employee.containsKey(eid1)) {
						throw new EmployeeNotFoundException("employee :" + eid1 + " not found");
					}
					Employee empobj = employee.get(eid1);
					System.out.println(empobj);
					break;
				case 4:
					System.out.println("Deleting Employee Details");
					System.out.println("enter id to delete");
					int eid2 = sc.nextInt();
					if (!employee.containsKey(eid2)) {
						throw new EmployeeNotFoundException("employee :" + eid2 + " not found");
					}
					employee.remove(eid2);
					System.out.println("Employee dleeted :" + eid2);
					break;
				case 5:
					Set<Entry<Integer, Employee>> result = employee.entrySet();
					if (result.isEmpty()) {
						throw new EmployeeNotFoundException("no employee found");
					}

					Iterator<Entry<Integer, Employee>> itr = result.iterator();
					while (itr.hasNext()) {
						Entry<Integer, Employee> finalResult = itr.next();
						System.out.println(finalResult.getKey() + " " + finalResult.getValue());
					}
					break;
				default:
					System.out.println("please enter valid option....");
					break;
				
				}
			} catch (Exception ee) {
				System.err.println("Error :" + ee.getMessage());
			}

		}
	}
}
