package com.emp.app;

public class EmployeeException extends Exception{

	public EmployeeException(String message) {
		super(message);
	}
}
