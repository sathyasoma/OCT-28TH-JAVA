package com.emp.app;

public class EmployeeAlredyExistsException extends EmployeeException {

	public EmployeeAlredyExistsException(String message) {
		super(message);
	}
}
