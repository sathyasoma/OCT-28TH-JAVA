package com.emp.app;

public class InvalidEmployeeInput extends EmployeeException{

	public InvalidEmployeeInput(String message) {
        super(message);
	}
}
