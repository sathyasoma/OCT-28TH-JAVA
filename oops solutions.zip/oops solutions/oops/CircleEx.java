package com.oops;

/*You can provide only a less restrictive or same-access modifier when overriding a method (b)*/




















// class Shape {
// protected void display() {
//     System.out.println("Display-base");
// }
//}
//public class CircleEx extends Shape{

	//  < access - modifier > void display() {  ----------------->>>>>>>>except this one remove all comments
	      //  System.out.println("Display-derived");
	//    }
//}

//a. Only protected can be used.
//B. public and protected both can be used.
//C. public, protected, and private can be used.
//d. Only public can be used.





