package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
public static void main(String[] args) {
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("keerthi");
	EntityManager entity=factory.createEntityManager();
	
	entity.getTransaction().begin();
	
	//inserting data into databse table
	Employee emp= new Employee(783, "sathya", 8373, "hyd");
	
	//entity.persist(emp);
	Employee fetchEmp=entity.find(Employee.class, 783);
	System.out.println("Employee Id :"+fetchEmp.getEmpid());
	System.out.println("\t Employee Name :"+fetchEmp.getEmpname());
	System.out.println("\t Employee Salry :"+fetchEmp.getEmpsal());
	System.out.println("\t Employee Address :"+fetchEmp.getEmpadd());
	
	//update
	
	fetchEmp.setEmpadd("kochi");
	fetchEmp.setEmpname("keerthi");
	fetchEmp.setEmpsal(90000);
	
	//entity.merge(fetchEmp);
	//entity.remove(fetchEmp);
	entity.getTransaction().commit();
	
	
	
	
	
	
	
	
	
}
}
