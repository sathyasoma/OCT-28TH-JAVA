package com.studentmanagementsystem;

import java.util.ArrayList;
import java.util.List;

public class StudentManagementSystem {
	 public static void main(String[] args) {
	        Student student1 = new Student("Alice");
	        Student student2 = new Student("Bob");

	        student1.enroll("Math");
	        student1.enroll("History");
	        student2.enroll("Computer Science");

	        student1.drop("Physics");

	        System.out.println(student1.getName() + "'s Courses: " + student1.getCourses());
	        System.out.println(student2.getName() + "'s Courses: " + student2.getCourses());
	    }
}
