package com.coffee.demo;

public class Espresso extends Coffee {

    public Espresso() {
        super(250, 0, 16, 4, "espresso");
    }
}
