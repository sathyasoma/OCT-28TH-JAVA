package com.coffee.demo;

public class Latte extends Coffee {
    public Latte() {
        super(350, 75, 20, 7, "latte");
    }
}
