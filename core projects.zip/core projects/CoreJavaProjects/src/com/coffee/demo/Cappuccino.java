package com.coffee.demo;

public class Cappuccino extends Coffee{

    public Cappuccino() {
        super(200, 100, 12, 6, "cappuccino");
    }
}
