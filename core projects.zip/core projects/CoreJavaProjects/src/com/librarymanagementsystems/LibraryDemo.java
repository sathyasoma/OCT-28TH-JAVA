package com.librarymanagementsystems;

public class LibraryDemo {

	 public static void main(String[] args) {
	        Book book1 = new Book("The Catcher in the Rye", "J.D. Salinger");
	        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee");

	        LibraryMember member1 = new LibraryMember("Alice");
	        LibraryMember member2 = new LibraryMember("Bob");

	        member1.borrowBook(book1);
	        member1.borrowBook(book2);
	        member2.borrowBook(book2);

	        member1.returnBook(book1);
	        member2.returnBook(book2);

	        System.out.println("Books borrowed by " + member1.getName() + ": " + member1.getBorrowedBooks());
	        System.out.println("Books borrowed by " + member2.getName() + ": " + member2.getBorrowedBooks());
	    }
}
