package com.librarymanagementsystems;

import java.util.ArrayList;
import java.util.List;

public class LibraryMember {
	

	private String name;
    private List<Book> borrowedBooks;

    public LibraryMember(String name) {
        this.name = name;
        this.borrowedBooks = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    public void borrowBook(Book book) {
        if (book.isAvailable()) {
            book.borrow();
            borrowedBooks.add(book);
        } else {
            System.out.println("Sorry, the book " + book.getTitle() + " is not available for borrowing.");
        }
    }

    public void returnBook(Book book) {
        if (borrowedBooks.contains(book)) {
            book.returnBook();
            borrowedBooks.remove(book);
        } else {
            System.out.println("You didn't borrow the book " + book.getTitle() + ".");
        }
    }

    @Override
    public String toString() {
        return name;
    }
}
