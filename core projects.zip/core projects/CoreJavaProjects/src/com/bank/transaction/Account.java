package com.bank.transaction;

public class Account {//POJO
	
	private long accNo;
	
	private String accHolderName;
	
	private String typeofAcc;
	
	private float accBal;
	
	private String address;
	
	private long contactno;
	
	public Account() {//default constr....
		// TODO Auto-generated constructor stub
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public String getTypeofAcc() {
		return typeofAcc;
	}

	public void setTypeofAcc(String typeofAcc) {
		this.typeofAcc = typeofAcc;
	}

	public float getAccBal() {
		return accBal;
	}

	public void setAccBal(float accBal) {
		this.accBal = accBal;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getContactno() {
		return contactno;
	}

	public void setContactno(long contactno) {
		this.contactno = contactno;
	}

	public Account(long accNo, String accHolderName, String typeofAcc, float accBal, String address, long contactno) {
		super();
		this.accNo = accNo;
		this.accHolderName = accHolderName;
		this.typeofAcc = typeofAcc;
		this.accBal = accBal;
		this.address = address;
		this.contactno = contactno;
	}


 
	
}
