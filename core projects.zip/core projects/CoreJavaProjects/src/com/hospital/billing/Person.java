package com.hospital.billing;

/**
 * This is a abstract and super class of
 * Patient class and Doctor class
 * This class is responsible for keeping the subclasses
 * name, age and contact information
 */

public abstract class Person {
    protected String name;
    protected int age;
    protected String contactInfo;

    public Person() {
    }

    public Person(String name, int age, String contactInfo) {
        this.name = name;
        this.age = age;
        this.contactInfo = contactInfo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    abstract void show();
}
