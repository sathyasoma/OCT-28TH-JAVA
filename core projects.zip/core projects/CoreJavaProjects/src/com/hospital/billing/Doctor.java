package com.hospital.billing;


public class Doctor extends Person {

    private String department;
    private String degree;
    private int doctorsFee;


    public Doctor(String name, String degree, String department, String contactInfo, int age, int doctorsFee) {
        super(name, age, contactInfo);
        this.department = department;
        this.degree = degree;
        this.doctorsFee = doctorsFee;
    }


    public String getDepartment() {
        return department;
    }


    public void setDepartment(String department) {
        this.department = department;
    }


    public String getDegree() {
        return degree;
    }


    public void setDegree(String degree) {
        this.degree = degree;
    }

    /**
     * @return Doctor's Fee as integer
     */

    public int getDoctorsFee() {
        return doctorsFee;
    }

    public void setDoctorsFee(int doctorsFee) {
        this.doctorsFee = doctorsFee;
    }


    @Override
    public void show() {
        System.out.println("Doctor Info :");
        System.out.println("Name        : " + super.getName());
        System.out.println("Degree      : " + this.degree);
        System.out.println("Department  : " + this.department);
        System.out.println("Contact     : " + super.getContactInfo());
        System.out.println("Age         : " + super.getAge());
        System.out.println("Doctor Fee  : " + this.doctorsFee);
        System.out.println();
    }
}
