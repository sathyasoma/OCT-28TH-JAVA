package com.core.Library_book_management_system;

import java.util.Scanner;

public class LibraryManagementSystem {
	// Maximum number of books the library can hold
	private static final int MAX_BOOKS = 100;

	// Arrays to hold book titles and authors
	private String[] bookTitles = new String[MAX_BOOKS];
	private String[] bookAuthors = new String[MAX_BOOKS];

	// To keep track of the number of books in the library
	private int bookCount = 0;

	// Scanner object to take user input
	private Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		LibraryManagementSystem library = new LibraryManagementSystem();
		library.run();
	}

	// Main loop to run the system
	public void run() {
		while (true) {
			System.out.println("\nLibrary Management System");
			System.out.println("1. Add a New Book");
			System.out.println("2. Search for a Book by Title");
			System.out.println("3. Display All Books");
			System.out.println("4. Remove a Book by Title");
			System.out.println("5. Exit");
			System.out.print("Choose an option: ");

			int choice = scanner.nextInt();
			scanner.nextLine(); // Consume newline

			switch (choice) {
			case 1:
				addBook();
				break;
			case 2:
				searchBook();
				break;
			case 3:
				displayBooks();
				break;
			case 4:
				removeBook();
				break;
			case 5:
				System.out.println("Exiting system...");
				return;
			default:
				System.out.println("Invalid option. Please try again.");
			}
		}
	}

	// Method to add a new book to the library
	private void addBook() {
		if (bookCount == MAX_BOOKS) {
			System.out.println("Library is full. Cannot add more books.");
			return;
		}

		System.out.print("Enter the book title: ");
		String title = scanner.nextLine();

		System.out.print("Enter the book author: ");
		String author = scanner.nextLine();

		bookTitles[bookCount] = title;
		bookAuthors[bookCount] = author;
		bookCount++;

		System.out.println("Book added successfully.");
	}

	// Method to search for a book by its title
	private void searchBook() {
		System.out.print("Enter the book title to search: ");
		String title = scanner.nextLine();

		for (int i = 0; i < bookCount; i++) {
			if (bookTitles[i].equalsIgnoreCase(title)) {
				System.out.println("Book Found:");
				System.out.println("Title: " + bookTitles[i]);
				System.out.println("Author: " + bookAuthors[i]);
				return;
			}
		}

		System.out.println("Book not found.");
	}

	// Method to display all books in the library
	private void displayBooks() {
		if (bookCount == 0) {
			System.out.println("No books in the library.");
			return;
		}

		System.out.println("Books in the Library:");
		for (int i = 0; i < bookCount; i++) {
			System.out.println((i + 1) + ". Title: " + bookTitles[i] + ", Author: " + bookAuthors[i]);
		}
	}

	// Method to remove a book by its title
	private void removeBook() {
		System.out.print("Enter the book title to remove: ");
		String title = scanner.nextLine();

		for (int i = 0; i < bookCount; i++) {
			if (bookTitles[i].equalsIgnoreCase(title)) {
				// Shift all subsequent books to the left
				for (int j = i; j < bookCount - 1; j++) {
					bookTitles[j] = bookTitles[j + 1];
					bookAuthors[j] = bookAuthors[j + 1];
				}

				bookCount--;
				System.out.println("Book removed successfully.");
				return;
			}
		}

		System.out.println("Book not found.");
	}
}
